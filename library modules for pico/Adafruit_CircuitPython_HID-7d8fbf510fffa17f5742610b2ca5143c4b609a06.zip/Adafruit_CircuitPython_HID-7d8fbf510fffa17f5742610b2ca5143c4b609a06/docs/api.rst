
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_hid.keyboard
   :members:

.. automodule:: adafruit_hid.keycode
   :members:

.. automodule:: adafruit_hid.keyboard_layout_us
   :members:
   :inherited-members:

.. automodule:: adafruit_hid.keyboard_layout_base
   :members:

.. automodule:: adafruit_hid.mouse
   :members:

.. automodule:: adafruit_hid.consumer_control
   :members:

.. automodule:: adafruit_hid.consumer_control_code
   :members:

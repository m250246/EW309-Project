Simple tests
-------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/register_rwbit.py
    :caption: examples/register_rwbit.py
    :linenos:

.. literalinclude:: ../examples/register_rwbits.py
    :caption: examples/register_rwbits.py
    :linenos:

.. literalinclude:: ../examples/register_simpletest.py
    :caption: examples/register_simpletest.py
    :linenos:

.. literalinclude:: ../examples/register_unarystruct.py
    :caption: examples/register_unarystruct.py
    :linenos:
